#include <SFML/Graphics.hpp>
#include <iostream>

sf::Clock reloj;
int main()
{
    // SETTINGS
    sf::ContextSettings settings;
    settings.antialiasingLevel = 8;
    sf::RenderWindow window(sf::VideoMode(1000, 500), "IPM Dungeon");
    window.setFramerateLimit(60);
    window.setMouseCursorVisible(false);
    window.setKeyRepeatEnabled(false);
    // PLAYER
    sf::RectangleShape juga(sf::Vector2f(50.0f, 50.0f));
    sf::CircleShape mira(10);
    sf::CircleShape coli_juga(50);
    coli_juga.setFillColor(sf::Color::Red);
    sf::Texture mira_text;
    sf::Texture jugador;
    float windowSizex = window.getSize().x;
    float windowSizey = window.getSize().y;
    juga.setPosition(windowSizex/ 2, windowSizey / 2);
    coli_juga.setPosition(windowSizex/ 2, windowSizey / 2);
    sf::Vector2f velocidad(0.f,0.f);
    float aceleracion = 400;
    bool keyA;
    bool keyD;
    bool keyW;
    bool keyS;
    // TEXTURES
    mira_text.loadFromFile("mira.png");
    jugador.loadFromFile("messi.jpg");
    mira.setTexture(&mira_text);
    juga.setTexture(&jugador);
    // BACKGROUND
      sf::Texture texture;
        texture.loadFromFile("room.jpg");
        sf::Sprite sprite;
        sf::Vector2u size = window.getSize();
        sprite.setTexture(texture);
        sprite.setOrigin(0, 0);

    // TEST OBJ COLLISION
    sf::RectangleShape object;
    object.setSize(sf::Vector2f(100, 100));
    object.setFillColor(sf::Color::Green);
    object.setPosition((windowSizex / 2) - 200, (windowSizey / 2) - 120);

    while (window.isOpen()){
        float deltaTime = reloj.restart().asSeconds();
        sf::Event event;
        while (window.pollEvent(event)){
            switch (event.type){
                case sf::Event::Closed:{
                    window.close();
                    break;
                }
                case sf::Event::LostFocus:{    
                    // myGame.pause();
                    
                }   
                 case sf::Event::GainedFocus:{    
                    // myGame.resume();
                    
                }
               
            } 
            sf::Vector2i mouse = sf::Mouse::getPosition(window);
            mira.setPosition((float)mouse.x, static_cast<float>(mouse.y));                                                                                   
        }           
        keyA = sf::Keyboard::isKeyPressed(sf::Keyboard::Key::A);
        keyD = sf::Keyboard::isKeyPressed(sf::Keyboard::Key::D);
        keyS = sf::Keyboard::isKeyPressed(sf::Keyboard::Key::S);
        keyW = sf::Keyboard::isKeyPressed(sf::Keyboard::Key::W);   


        if(keyA == true){
            velocidad.x =  aceleracion * deltaTime;
            juga.move(-velocidad.x, 0.f);    
        }
        if(keyD == true){
            velocidad.x =  aceleracion * deltaTime;
            juga.move(velocidad.x, 0.f);
        }
        if(keyS == true){
          velocidad.y =  aceleracion * deltaTime;
            juga.move(0.f, velocidad.y);   
        }
        if(keyW == true){
             velocidad.y =  aceleracion * deltaTime;
            juga.move(0.f, -velocidad.y);     
        }        

        //Check collision with object
sf::FloatRect juga_boundingBox = juga.getGlobalBounds();

if (juga_boundingBox.intersects(object.getGlobalBounds()) && juga.getPosition().y +100 < object.getPosition().y + 5 && juga.getPosition().y + 50 > object.getPosition().y && juga.getPosition().y < object.getPosition().y)
{
    juga.setPosition(juga.getPosition().x, object.getPosition().y - 100);
    std::cout << "ARRIBA  " << std::endl;
}
else if (juga_boundingBox.intersects(object.getGlobalBounds()) && juga.getPosition().x > object.getPosition().x + 90 && juga.getPosition().x < object.getPosition().x + 99)
{
    juga.setPosition(object.getPosition().x + 100, juga.getPosition().y);
    velocidad.x = 0;
    std::cout << "DERECHA" << std::endl;
}
else if (juga_boundingBox.intersects(object.getGlobalBounds()) && juga.getPosition().x + 50 < object.getPosition().x + 10 && juga.getPosition().x + 50 > object.getPosition().x)
{
    juga.setPosition(object.getPosition().x - 50, juga.getPosition().y);
    velocidad.x = 0;
    std::cout << "IZQUIERDA" << std::endl;
}
else if (juga_boundingBox.intersects(object.getGlobalBounds()) && juga.getPosition().y > object.getPosition().y + 97 && juga.getPosition().y < object.getPosition().y + 99)
{
    juga.setPosition(juga.getPosition().x, object.getPosition().y + 100);
    velocidad.y = 0;
    std::cout << "ABAJO" << std::endl;
}   





        window.clear();
        window.draw(sprite);
        window.draw(juga);
        window.draw(object);
        coli_juga.setPosition(juga.getSize().x, juga.getSize().y);
        window.draw(coli_juga);
        window.draw(mira);
        window.display();
        
    }
    return 0;
 
}       