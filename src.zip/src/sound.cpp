#pragma once

#include <SFML/Audio.hpp>
#include <SFML/Graphics.hpp>
#include <iostream>

class sound{
    public:
        sound(std::string bytedir, float volume){
            if (!music.openFromFile(bytedir)) printf("Error loading byte from %s...", bytedir);
            music.setVolume(volume);
        }

        // --- PLACE HOLDER ---
        void input(){
            if(sf::Keyboard::isKeyPressed(sf::Keyboard::Num1) && (music.Stopped || music.Paused)) music.play();
            else if(sf::Keyboard::isKeyPressed(sf::Keyboard::Num2) && music.Playing) music.stop();
        }

    private:
        sf::Music music;
};