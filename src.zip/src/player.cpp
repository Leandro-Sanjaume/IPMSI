#pragma once

#include <iostream>
#include <SFML/Graphics.hpp>
#include <cmath>
#include <vector>
#include "bullet.cpp"
using namespace std;
class player{
    public:
        player(std::string imgdirectory, sf::Vector2f inicial_pos){
            if(!ptexture.loadFromFile(imgdirectory)) printf("Error loading texture from %s...", imgdirectory);
            //psprite = sf::Sprite(ptexture, current_frame);
            psprite.setTexture(ptexture);
            psprite.setOrigin(19,27);
            psprite.setPosition(inicial_pos);
            aim.setRadius(10.0f);
            aim.setFillColor(sf::Color::Blue);
            aim.setOrigin(aim.getRadius(), aim.getRadius());
        }
        
        void change_velocity(sf::Vector2f sourcew, float dt){
             psprite.setPosition(psprite.getPosition() + normalize(sourcew) * (acceleration * dt));
        }

        void draw_player(sf::RenderWindow &window){
            window.draw(psprite);
            window.draw(aim);
        }

        sf::Vector2f move_player(float dt, sf::RenderWindow &window){
            int xmove = sf::Keyboard::isKeyPressed(sf::Keyboard::D) - sf::Keyboard::isKeyPressed(sf::Keyboard::A);
            int ymove = sf::Keyboard::isKeyPressed(sf::Keyboard::S) - sf::Keyboard::isKeyPressed(sf::Keyboard::W);

            sf::Vector2f movement(xmove, ymove);
            psprite.setPosition(psprite.getPosition() + normalize(movement) * (acceleration * dt));
            update_sprite(movement);

            move_aim(window);

            sprite_timer++;
            delay++;
            return movement;
        }

        void shoot(std::vector<bullet> &src){
            if(delay > bullet_timer && sf::Mouse::isButtonPressed(sf::Mouse::Left)){
                src.push_back(bullet("/home/serra/Escritorio/workspace/TP_Integrador/assets/sprites/player/player_bullet.png" ,get_absolute_position(), get_aim_position(), 25));
                delay = 0;
                
            }
            else if(sf::Mouse::isButtonPressed(sf::Mouse::Right)){
                src.push_back(bullet("/home/serra/Escritorio/workspace/TP_Integrador/assets/sprites/player/player_bullet.png", get_absolute_position(), get_aim_position(), 70));
            }
        }

        sf::Vector2f get_absolute_position(){
            return sf::Vector2f(psprite.getPosition().x, psprite.getPosition().y);
        }

        sf::Vector2f get_size(){
            return sf::Vector2f(psprite.getScale());
        }

    private:
        sf::Texture ptexture;
        sf::Sprite psprite;
        int sprite_originx = 0;
        int sprite_timer = 0;
        sf::IntRect current_frame = sf::IntRect(sprite_originx, 0, 32, 36);
        
        sf::CircleShape aim;

        int vida;
        float speed = 50;
        float acceleration = 5;
        int delay = 0;
        int bullet_timer = 35;

        sf::Vector2f normalize(sf::Vector2f source){
            float length = sqrt(pow(source.x, 2) + pow(source.y, 2));
            if(length != 0) return sf::Vector2f((source.x / length) * speed, (source.y / length) * speed);
            else return source * speed;
        }

        void move_aim(sf::RenderWindow &window){
            sf::Vector2i mouse = sf::Mouse::getPosition(window);
            // printf("Mouse: X = %F | Y = %F\n", get_aim_position().x, get_aim_position().y);
            aim.setPosition((float)mouse.x, (float)mouse.y);
            if(get_aim_position().x > 0) psprite.setScale(1.f, 1.f);
            if(get_aim_position().x < 0) psprite.setScale(-1.f, 1.f);
        }

        void update_sprite(sf::Vector2f source){
            if(source != sf::Vector2f(0, 0) && sprite_originx != 96 && sprite_timer > 5){
                sprite_originx += 32;
                sprite_timer = 0;
            }
            else if(source == sf::Vector2f(0, 0) || sprite_originx == 96) sprite_originx = 0;
            psprite.setTextureRect(sf::IntRect(sprite_originx, 0, 32,36));
        }

        sf::Vector2f get_aim_position(){
            return sf::Vector2f(aim.getPosition().x - psprite.getPosition().x, aim.getPosition().y - psprite.getPosition().y);
        }
};