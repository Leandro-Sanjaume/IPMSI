#include <SFML/Graphics.hpp>
#include <iostream>
#include <vector>
#include <cmath>
#include <array>
#include <math.h> 
#include <cfloat>
#include <stack>
#include "player.cpp"
#include "bullet.cpp"
#include "sound.cpp"
#include "menu.cpp"
#include "maps.cpp"
//#include "collitions.cpp"
//#include "func.cpp"

#define X_MAX 1280
#define X_STEP 20
#define Y_MAX 720
#define Y_STEP 20

using namespace std;

void check_colision(sf::RectangleShape& jugador, sf::RectangleShape& object, sf::Vector2f& velocidad,  float delta_time, player& p1)
{
	sf::FloatRect jugador_boundingBox = jugador.getGlobalBounds();
	

	if (jugador_boundingBox.intersects(object.getGlobalBounds()) && jugador.getPosition().y + jugador.getSize().y < object.getPosition().y + 7 && jugador.getPosition().y + jugador.getSize().y > object.getPosition().y && jugador.getPosition().y < object.getPosition().y)
	{
		jugador.setPosition(jugador.getPosition().x, object.getPosition().y - jugador.getSize().y);
		p1.change_velocity(sf::Vector2f(velocidad.x, 0), delta_time);
	}
	else if (jugador_boundingBox.intersects(object.getGlobalBounds()) && jugador.getPosition().x > object.getPosition().x + object.getSize().x - 7 && jugador.getPosition().x < object.getPosition().x + object.getSize().x + 7)
	{
		jugador.setPosition(object.getPosition().x + object.getSize().x, jugador.getPosition().y);
		p1.change_velocity(sf::Vector2f(0,velocidad.y), delta_time);

	}
	else if (jugador_boundingBox.intersects(object.getGlobalBounds()) && jugador.getPosition().x + jugador.getSize().x < object.getPosition().x + 7 && jugador.getPosition().x + jugador.getSize().x > object.getPosition().x - 7)
	{
		jugador.setPosition(object.getPosition().x - jugador.getSize().x, jugador.getPosition().y);
	p1.change_velocity(sf::Vector2f(0,velocidad.y), delta_time);

	}
	else if (jugador_boundingBox.intersects(object.getGlobalBounds()) && jugador.getPosition().y > object.getPosition().y + object.getSize().y - 7 && jugador.getPosition().y < object.getPosition().y + object.getSize().y + 7)
	{
		jugador.setPosition(jugador.getPosition().x, object.getPosition().y + object.getSize().y);
	p1.change_velocity(sf::Vector2f(velocidad.x, 0), delta_time);

	}
	return;
}


void menuActive(Menu menu, sf::RenderWindow &window){
	while (1){
		int slc = menu.changed(window);
		if(slc == 0) break;
		if(slc == 1) continue;
		if(slc == 2){
			window.close();
			break;
		}
		window.clear();
		menu.draw(window);
		window.display();
	}
}


struct Node
{
	int y;
	int x;
	int parentX;
	int parentY;
	float gCost;
	float hCost;
	float fCost;
};


inline bool operator < (const Node& lhs, const Node& rhs)
{ //We need to overload "<" to put our struct into a set
	return lhs.fCost < rhs.fCost;
}


class Cordinate {
public:


	static bool isValid(int x, int y) { //If our Node is an obstacle it is not valid
		int id = x + y * (X_MAX / X_STEP);
		/// World borders check
		if (1) {
			if (x < 0 || y < 0 || x >= X_MAX || y >= Y_MAX) {
				return false;
			}
			return true;
		}
		return false;
	}

	static bool isDestination(int x, int y, Node dest) {
		if (x == dest.x && y == dest.y) {
			return true;
		}
		return false;
	}

	static double calculateH(int x, int y, Node dest) {
		double H = (sqrt((x - dest.x) * (x - dest.x)
			+ (y - dest.y) * (y - dest.y)));
		return H;
	}

	static std::vector<Node> makePath(std::array<std::array<Node, (Y_MAX / Y_STEP)>, (X_MAX / X_STEP)> map, Node dest) {
		try {
			int x = dest.x;
			int y = dest.y;
			std::stack<Node> path;
			std::vector<Node> usablePath;

			while (!(map[x][y].parentX == x && map[x][y].parentY == y)
				&& map[x][y].x != -1 && map[x][y].y != -1)
			{
				path.push(map[x][y]);
				int tempX = map[x][y].parentX;
				int tempY = map[x][y].parentY;
				x = tempX;
				y = tempY;

			}
			path.push(map[x][y]);

			while (!path.empty()) {
				Node top = path.top();
				path.pop();
				//cout << top.x << " " << top.y << endl;
				usablePath.emplace_back(top);
			}
			return usablePath;
		}
		catch (const std::exception& e) {
			std::cout << e.what() << std::endl;
		}
	}


	static std::vector<Node> aStar(Node player, Node dest) {
		std::vector<Node> empty;
		if (isValid(dest.x, dest.y) == false) {
			std::cout << "Destination is an obstacle" << std::endl;
			return empty;
			//Destination is invalid
		}
		if (isDestination(player.x, player.y, dest)) {
			std::cout << "You are the destination" << std::endl;
			return empty;
			//You clicked on yourself
		}
		bool closedList[(X_MAX / X_STEP)][(Y_MAX / Y_STEP)];

		//Initialize whole map
		//Node allMap[50][25];
		std::array<std::array<Node, (Y_MAX / Y_STEP)>, (X_MAX / X_STEP)> allMap;
		for (int x = 0; x < (X_MAX / X_STEP); x++) {
			for (int y = 0; y < (Y_MAX / Y_STEP); y++) {
				allMap[x][y].fCost = FLT_MAX;
				allMap[x][y].gCost = FLT_MAX;
				allMap[x][y].hCost = FLT_MAX;
				allMap[x][y].parentX = -1;
				allMap[x][y].parentY = -1;
				allMap[x][y].x = x;
				allMap[x][y].y = y;

				closedList[x][y] = false;
			}
		}

		//Initialize our starting list
		int x = player.x;
		int y = player.y;
		allMap[x][y].fCost = 0.0;
		allMap[x][y].gCost = 0.0;
		allMap[x][y].hCost = 0.0;
		allMap[x][y].parentX = x;
		allMap[x][y].parentY = y;

		std::vector<Node> openList;
		openList.emplace_back(allMap[x][y]);
		bool destinationFound = false;

		while (!openList.empty() && openList.size() < (X_MAX / X_STEP) * (Y_MAX / Y_STEP)) {
			Node node;
			do {
				//This do-while loop could be replaced with extracting the first
				//element from a set, but you'd have to make the openList a set.
				//To be completely honest, I don't remember the reason why I do
				//it with a vector, but for now it's still an option, although
				//not as good as a set performance wise.
				float temp = FLT_MAX;
				std::vector<Node>::iterator itNode;
				for (std::vector<Node>::iterator it = openList.begin();
					it != openList.end(); it = next(it)) {
					Node n = *it;
					if (n.fCost < temp) {
						temp = n.fCost;
						itNode = it;
					}
				}
				node = *itNode;
				openList.erase(itNode);
			} while (isValid(node.x, node.y) == false);

			x = node.x;
			y = node.y;
			closedList[x][y] = true;

			//For each neighbour starting from North-West to South-East
			for (int newX = -1; newX <= 1; newX++) {
				for (int newY = -1; newY <= 1; newY++) {
					double gNew, hNew, fNew;
					if (isValid(x + newX, y + newY)) {
						if (isDestination(x + newX, y + newY, dest))
						{
							//Destination found - make path
							allMap[x + newX][y + newY].parentX = x;
							allMap[x + newX][y + newY].parentY = y;
							destinationFound = true;
							return makePath(allMap, dest);
						}
						else if (closedList[x + newX][y + newY] == false)
						{
							gNew = node.gCost + 1.0;
							hNew = calculateH(x + newX, y + newY, dest);
							fNew = gNew + hNew;
							// Check if this path is better than the one already present
							if (allMap[x + newX][y + newY].fCost == FLT_MAX ||
								allMap[x + newX][y + newY].fCost > fNew)
							{
								// Update the details of this neighbour node
								allMap[x + newX][y + newY].fCost = fNew;
								allMap[x + newX][y + newY].gCost = gNew;
								allMap[x + newX][y + newY].hCost = hNew;
								allMap[x + newX][y + newY].parentX = x;
								allMap[x + newX][y + newY].parentY = y;
								openList.emplace_back(allMap[x + newX][y + newY]);
							}
						}
					}
				}
			}
		}
		if (destinationFound == false) {
			std::cout << "Destination not found" << std::endl;
			return empty;
		}
	}
};

void perder_vida(sf::RectangleShape  receiver, int &vida, int damage, sf::CircleShape coli, int vida_atacante, int &ancho, int largo, float aux, sf::RectangleShape& object) {
	if (vida_atacante <= 0) {
		return;
	}
	sf::FloatRect attacker_boundingBox = coli.getGlobalBounds();
	sf::FloatRect receiver_boundingBox = receiver.getGlobalBounds();

	if (attacker_boundingBox.intersects(receiver_boundingBox)) {
		if (vida <= 0) {
		std::cout << "Moriste" << std::endl;
		
		}
		else 
		{
			ancho -= aux;
			vida -= damage;
		    object.setSize(sf::Vector2f(ancho, largo));
		}
	}
}
void bullet_collision( std::vector<bullet> &bullets, sf::RectangleShape receiver, bool &bullet_hit){
	 for(int i = 0; i < bullets.size(); i++){
		sf::FloatRect boundingBox_bullets = bullets[i].bsprite.getGlobalBounds();
		sf::FloatRect boundingBox_receiver = receiver.getGlobalBounds();
	
			
            if(boundingBox_bullets.intersects(boundingBox_receiver)){
				bullets.erase(bullets.begin() + i);
				bullet_hit = true;
				//break;
			}
        }
}


int main()
{
    sf::ContextSettings settings;
    settings.antialiasingLevel = 8;
    sf::RenderWindow window(sf::VideoMode(/*sf::VideoMode::getDesktopMode()*/ 1280, 720), "Wachin magico que te caga a tiros", sf::Style::Default, settings);
    sf::Vector2i screencenter(sf::VideoMode::getDesktopMode().width/2 - window.getSize().x/2, sf::VideoMode::getDesktopMode().height/2 - window.getSize().y/2);
    window.setKeyRepeatEnabled(true);
    window.setPosition(screencenter);
    window.setMouseCursorVisible(false);
	window.setFramerateLimit(60);
	Menu menu(window.getSize().x, window.getSize().y);
	menuActive(menu, window);

    sf::Clock reloj;
    sf::Clock ataque_cooldown_enemigo;

    player p1("assets/sprites/player/player_atlas32x32.png", sf::Vector2f(window.getSize().x/2, window.getSize().y/2));
    sf::RectangleShape p1_box(sf::Vector2f(32,36));
    p1_box.setOrigin(p1_box.getSize().x /2, p1_box.getSize().y /2);
    p1_box.setPosition(p1.get_absolute_position());
    int vida_juga = 100; 
	int ancho_juga = 500;
 	int largo_juga = 20;
 	int largo_en = 10;
 	int ancho_en = 100;
	sf::RectangleShape HUD_vida_jugador(sf::Vector2f(500.0f, 20.f));
 	HUD_vida_jugador.setFillColor(sf::Color::Green);
 	HUD_vida_jugador.setPosition(20, 30);	
    sf::CircleShape circulo_path_jugador(37);
    sf::CircleShape coli_jugador(52);
	coli_jugador.setFillColor(sf::Color::Transparent);
	coli_jugador.setOutlineColor(sf::Color::White);
	coli_jugador.setOutlineThickness(2);
    coli_jugador.setOrigin(coli_jugador.getRadius(), coli_jugador.getRadius());
	coli_jugador.setPosition(p1.get_absolute_position().x, p1.get_absolute_position().y);
	circulo_path_jugador.setFillColor(sf::Color::Transparent);
	circulo_path_jugador.setOutlineColor(sf::Color::Red);
	circulo_path_jugador.setOutlineThickness(4);
    circulo_path_jugador.setOrigin(circulo_path_jugador.getRadius(),circulo_path_jugador.getRadius());
	circulo_path_jugador.setPosition(p1.get_absolute_position().x, p1.get_absolute_position().y);

    sound music("assets/sounds/sound1.wav", 100.f);
    std::vector<bullet> bullets;
    bool bullet_hit = false;
    // ENEMIGO
	sf::RectangleShape enemy(sf::Vector2f(50.0f, 50.0f));
	sf::Texture enemy_text;
	enemy.setPosition(window.getSize().x / 2 + 100, window.getSize().y / 2);
    sf::CircleShape coli_enemigo(52);
	coli_enemigo.setFillColor(sf::Color::Transparent);
	coli_enemigo.setOutlineColor(sf::Color::Blue);
	coli_enemigo.setOutlineThickness(2);
	coli_enemigo.setPosition(enemy.getPosition().x, enemy.getPosition().y);
   
    float valor_cooldown_enem = 1;
    int  damage_ene = 20;
    int vida_enemigo = 100;
	float ecuacion_damage_al_juga = ancho_juga / vida_juga * damage_ene;
	float ecuacion_damage_al_ene = ancho_en / vida_enemigo * 5;
    bool focus = true;
	sf::RectangleShape HUD_vida_enemigo(sf::Vector2f(100.0f, 10.f));
	HUD_vida_enemigo.setFillColor(sf::Color::Red);

	 float cooldown_enemigo = ataque_cooldown_enemigo.restart().asSeconds() + 1;
   tilemap map("assets/sprites/mapgen/wall_atlas64x64.png" ,sf::Vector2u(64, 64));
    if(!map.load()) return EXIT_FAILURE;

    while(window.isOpen())
    {
        float delta_time = reloj.restart().asSeconds();
        sf::Event event;

        while(window.pollEvent(event))
        {
            switch (event.type)
            {

            case event.Closed:
                window.close();
                break;

            case sf::Event::LostFocus:
                focus = false;
                break;
                    
            case sf::Event::GainedFocus:  
                focus = true;
                break;

            default:
                break;
            }
        }

        // Movement
        sf::Vector2f dir;
        if(focus){
            sf::Vector2f dir = p1.move_player(delta_time, window);
            p1.shoot(bullets);
        }

        for(int i = 0; i < bullets.size(); i++){
            bullets[i].move_bullet(30, delta_time);
        }

		if (vida_enemigo > 0) {
        // PATHFINDING 
		Node enemigo;
		enemigo.x = enemy.getPosition().x / X_STEP;
		enemigo.y = enemy.getPosition().y / Y_STEP;

		Node destination;
		destination.x = p1.get_absolute_position().x / X_STEP;
		destination.y = p1.get_absolute_position().y / Y_STEP;

		for (Node node : Cordinate::aStar(enemigo, destination)) {

			sf::FloatRect jugador_boundingBox = circulo_path_jugador.getGlobalBounds();
			sf::FloatRect enemigo_boundingBox = enemy.getGlobalBounds();
			if (enemigo_boundingBox.intersects(jugador_boundingBox) == false) {
				if (enemy.getPosition().x - enemy.getSize().x - 10 > node.x * 20) {
					enemy.move(-0.2f, 0.f);
				}
				else if (enemy.getPosition().x + p1.get_size().x < node.x * 20) {
					enemy.move(0.2, 0.f);
				}

				if (enemy.getPosition().y - enemy.getSize().y - 10 > node.y * 20) {
					enemy.move(0.f, -0.2f);
				}
				else if (enemy.getPosition().y + p1.get_size().y < node.y * 20) {
					enemy.move(0.f, 0.2f);

				}
			}
			else {
				enemy.move(0.f, 0.f);
				}
			}
        }
     if (ataque_cooldown_enemigo.getElapsedTime().asSeconds() > cooldown_enemigo) {
			cout << "jamon" << endl;
	perder_vida(p1_box, vida_juga, damage_ene, coli_enemigo, vida_enemigo, ancho_juga, largo_juga, ecuacion_damage_al_juga, HUD_vida_jugador);
		cooldown_enemigo = ataque_cooldown_enemigo.restart().asSeconds() + valor_cooldown_enem;
		cout << vida_juga << endl;
		}

		HUD_vida_enemigo.setPosition(enemy.getPosition().x - 20, enemy.getPosition().y - 20);
        coli_jugador.setPosition(p1.get_absolute_position().x - p1.get_size().x / 1.9, p1.get_absolute_position().y - p1.get_size().y / 1.9);
		coli_enemigo.setPosition(enemy.getPosition().x - enemy.getSize().x / 1.9, enemy.getPosition().y - enemy.getSize().y / 1.9);
		circulo_path_jugador.setPosition(p1.get_absolute_position().x - p1.get_size().x / 4.5, p1.get_absolute_position().y - p1.get_size().y / 4.5);


		if(bullet_hit == true){
			
			vida_enemigo -=  bullets[0].damage_bullet;
			ancho_en -= ecuacion_damage_al_ene;
		    HUD_vida_enemigo.setSize(sf::Vector2f(ancho_en, largo_en));
			bullet_hit = false;
		}


        // Draw
        window.clear();
        window.draw(map);
        if (vida_enemigo > 0) {
			bullet_collision(bullets, enemy, bullet_hit);
			check_colision(p1_box, enemy, dir, delta_time,p1);
			window.draw(enemy);
			window.draw(coli_enemigo);
			window.draw(HUD_vida_enemigo);	
		}

		if (vida_juga > 0) {
			window.draw(HUD_vida_jugador);
			window.draw(coli_jugador);
			window.draw(circulo_path_jugador);
		}
        p1.draw_player(window);
        for(int i = 0; i < bullets.size(); i++){
            bullets[i].draw_bullet(window);
            if(bullets[i].get_absolute_position().y > window.getSize().y ||
               bullets[i].get_absolute_position().y < 0 ||
               bullets[i].get_absolute_position().x > window.getSize().x ||
               bullets[i].get_absolute_position().x < 0) bullets.erase(bullets.begin() + i);
        }

        window.display();

        // Watches
        //printf("Bullets = %lu \n", bullets.size());
        //printf("Delta = %f \n", delta_time);
        //printf("%i\n", vida_juga);
    }
	return 0;
}