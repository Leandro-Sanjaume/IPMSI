
#include <SFML/Graphics.hpp>
#include <vector>
#include <iostream>
#define Max_NUMBER_OF_ITEMS 3

class Menu{
	private:
    int selectedItemIndex = 0;
	std::vector<Menu> menu_inicial;
    sf:: Font font;
    sf:: Text menu[Max_NUMBER_OF_ITEMS]; 

	    void move_up(){
            if (selectedItemIndex - 1 >= 0){
                menu[selectedItemIndex].setColor(sf::Color::White);
                selectedItemIndex--;
                menu[selectedItemIndex].setColor(sf::Color(0,0,255));
            }
        }


        void move_down(){
			if (selectedItemIndex + 1 < Max_NUMBER_OF_ITEMS){
				menu[selectedItemIndex].setColor(sf::Color::White);
				selectedItemIndex++;
				menu[selectedItemIndex].setColor(sf::Color(0,0,255));
			}
  		}


    public:
        Menu(float width, float height){
			if (!font.loadFromFile("assets/fonts/arial.ttf"))
			{
				// handle error
			}

            menu[0].setFont(font);
            menu[0].setColor(sf::Color::White);
            menu[0].setString("Jugar");
			menu[0].setCharacterSize(50);
			menu[0].setOrigin(menu[0].getLocalBounds().width /2, menu[0].getLocalBounds().height /2);
			menu[0].setPosition(width/2,(height/2));


            menu[1].setFont(font);
            menu[1].setColor(sf::Color::White);
            menu[1].setString("Opciones");
			menu[1].setCharacterSize(50);
			menu[1].setOrigin(menu[1].getLocalBounds().width /2, menu[1].getLocalBounds().height /2);
			menu[1].setPosition(width/2,(height/2)+65);

            
            menu[2].setFont(font);
            menu[2].setColor(sf::Color::White);
            menu[2].setString("Salir");
			menu[2].setCharacterSize(50);
			menu[2].setOrigin(menu[2].getLocalBounds().width /2, menu[2].getLocalBounds().height /2);
			menu[2].setPosition(width/2,(height/2)+125);
		}

		
		int GetPressedItem() { return selectedItemIndex;}
	

		void draw(sf::RenderWindow &window){
			for (int i = 0; i < Max_NUMBER_OF_ITEMS; i++){ 	
			window.draw(menu[i]);
			}
		}


		int changed(sf::RenderWindow &window){
			if(sf::Keyboard::isKeyPressed(sf::Keyboard::Up)) move_up();
			if(sf::Keyboard::isKeyPressed(sf::Keyboard::Down)) move_down();
			if(sf::Keyboard::isKeyPressed(sf::Keyboard::Return)) return GetPressedItem();
			return 3;
		}
};

//esto va en el main 
/*
int main()
{sf::RenderWindow window(sf::VideoMode(1000, 1000), "SFML WORK!");

	Menu menu(window.getSize().x, window.getSize().y);
    std::cout << window.getSize().x << ", " << window.getSize().y;

	while (window.isOpen())
	{
		sf::Event event;

		while (window.pollEvent(event))
		{ 
			switch (event.type)
			{
			case sf::Event::KeyReleased:
				switch (event.key.code)
				{
				case sf::Keyboard::Up:
					menu.move_up();
                    std::cout<<"esta";
					break;

				case sf::Keyboard::Down:
					menu.move_down();
					break;

				case sf::Keyboard::Return:
					switch (menu.GetPressedItem())
					{
					case 0:
						std::cout << "Play button has been pressed" << std::endl;
						break;
					case 1:
						std::cout << "Option button has been pressed" << std::endl;
						break;
					case 2:
						window.close();
						break;
					}

					break;
				}

				break;
			case sf::Event::Closed:
				window.close();

				break;

			}
		}



		window.clear();

		menu.draw(window);

		window.display();
	}
}*/
