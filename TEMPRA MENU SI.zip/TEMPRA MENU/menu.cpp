
#include <SFML/Graphics.hpp>
#include <vector>
#include <iostream>
#define Max_NUMBER_OF_ITEMS 3

using namespace std;;

class Menu{
	private:
    int selectedItemIndex = 0;
	vector<Menu> menu_inicial;
    sf:: Font font;
    sf:: Text menu[Max_NUMBER_OF_ITEMS]; 
	sf::Texture texture_logo;
	sf::Sprite sprite_ipm;
	sf::Sprite sprite1;
	sf::Texture Background;

	    void move_up(){
            if (selectedItemIndex - 1 >= 0){
                menu[selectedItemIndex].setColor(sf::Color::White);
                selectedItemIndex--;
                menu[selectedItemIndex].setColor(sf::Color(0,0,255));
            }
        }


        void move_down(){
			if (selectedItemIndex + 1 < Max_NUMBER_OF_ITEMS){
				menu[selectedItemIndex].setColor(sf::Color::White);
				selectedItemIndex++;
				menu[selectedItemIndex].setColor(sf::Color(0,0,255));
			}
  		}


    public:
        Menu(float width, float height){
			Background.loadFromFile("assets/sprites/Background.jpg");
			sprite1.setTexture(Background);
			sprite1.setOrigin(menu[1].getLocalBounds().width /2, menu[1].getLocalBounds().height /2);
			sprite1.setScale(0.8,0.75);

			texture_logo.loadFromFile("assets/sprites/IPM_Dungeon.png");

			sprite_ipm.setTexture(texture_logo);
			sprite_ipm.setOrigin(menu[1].getLocalBounds().width /2, menu[1].getLocalBounds().height /2);
			sprite_ipm.setPosition((width/2)-250,(height/2)-300);

			font.loadFromFile("assets/fonts/arial.ttf");
		
            menu[0].setFont(font);
            menu[0].setColor(sf::Color::Blue);
            menu[0].setString("Jugar");
			menu[0].setCharacterSize(50);
			menu[0].setOrigin(menu[0].getLocalBounds().width /2, menu[0].getLocalBounds().height /2);
			menu[0].setPosition(width/2,(height/2));


            menu[1].setFont(font);
            menu[1].setColor(sf::Color::White);
            menu[1].setString("Opciones");
			menu[1].setCharacterSize(50);
			menu[1].setOrigin(menu[1].getLocalBounds().width /2, menu[1].getLocalBounds().height /2);
			menu[1].setPosition(width/2,(height/2)+65);

            
            menu[2].setFont(font);
            menu[2].setColor(sf::Color::White);
            menu[2].setString("Salir");
			menu[2].setCharacterSize(50);
			menu[2].setOrigin(menu[2].getLocalBounds().width /2, menu[2].getLocalBounds().height /2);
			menu[2].setPosition(width/2,(height/2)+125);
		}

		
		int GetPressedItem() { return selectedItemIndex;}
	

		void draw(sf::RenderWindow &window){
			window.draw(sprite1);
			window.draw(sprite_ipm);
			for (int i = 0; i < Max_NUMBER_OF_ITEMS; i++){ 	
			window.draw(menu[i]);
			}
		}


		void select_option(int selection, string &window_type, sf::RenderWindow &window){
			if(selection == 0) window_type = "juego";
			else if(selection == 1) window_type = "opciones";
			else if(selection == 2) window.close();

			cout << window_type << endl;
		}


		int changed(sf::RenderWindow &window, string &window_type, sf::Keyboard::Key key_pressed){
			if(key_pressed == sf::Keyboard::Up) move_up();
			else if(key_pressed == sf::Keyboard::Down) move_down();
			else if(key_pressed == sf::Keyboard::Return) select_option(GetPressedItem(), window_type, window);
			return 3;
		}
};

//esto va en el main 
/*
int main()
{sf::RenderWindow window(sf::VideoMode(1000, 1000), "SFML WORK!");

	Menu menu(window.getSize().x, window.getSize().y);
    cout << window.getSize().x << ", " << window.getSize().y;

	while (window.isOpen())
	{
		sf::Event event;

		while (window.pollEvent(event))
		{ 
			switch (event.type)
			{
			case sf::Event::KeyReleased:
				switch (event.key.code)
				{
				case sf::Keyboard::Up:
					menu.move_up();
                    cout<<"esta";
					break;

				case sf::Keyboard::Down:
					menu.move_down();
					break;

				case sf::Keyboard::Return:
					switch (menu.GetPressedItem())
					{
					case 0:
						cout << "Play button has been pressed" << endl;
						break;
					case 1:
						cout << "Option button has been pressed" << endl;
						break;
					case 2:
						window.close();
						break;
					}

					break;
				}

				break;
			case sf::Event::Closed:
				window.close();

				break;

			}
		}



		window.clear();

		menu.draw(window);

		window.display();
	}
}*/
