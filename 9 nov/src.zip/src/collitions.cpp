#pragma once

#include <iostream>
#include <SFML/Graphics.hpp>
#include <vector>
//#include "func.cpp"

class collition{
    public:

        collition(sf::FloatRect global_bounds){
            bounds = global_bounds;
        }

        //collition(sf::CircleShape target){}

        void check_collition(std::vector<collition> source){
            for(int i = 0; i < source.size(); i++){
                if(bounds.intersects(source[i].bounds)){
                    printf("tuki\n");
                }
            }
        }

    private:
    sf::FloatRect bounds;

};

/*
sf::FloatRect juga_boundingBox = juga.getGlobalBounds();

if (juga_boundingBox.intersects(object.getGlobalBounds()) &&
    juga.getPosition().y + juga.getSize().y < object.getPosition().y + 7 &&
    juga.getPosition().y +  juga.getSize().y > object.getPosition().y &&
    juga.getPosition().y < object.getPosition().y)
{
    juga.setPosition(juga.getPosition().x, object.getPosition().y - 50);
    std::cout << "ARRIBA  " << std::endl;
}
else if (juga_boundingBox.intersects(object.getGlobalBounds()) && juga.getPosition().x > object.getPosition().x + object.getSize().x -7 && juga.getPosition().x < object.getPosition().x + object.getSize().x +7)
{
    juga.setPosition(object.getPosition().x + 100, juga.getPosition().y);
    velocidad.x = 0;
    std::cout << "DERECHA" << std::endl;
}
else if (juga_boundingBox.intersects(object.getGlobalBounds()) && juga.getPosition().x + juga.getSize().x < object.getPosition().x + 7 && juga.getPosition().x +  juga.getSize().x > object.getPosition().x - 7)
{ 
    juga.setPosition(object.getPosition().x - 50, juga.getPosition().y);
    velocidad.x = 0;
    std::cout << "IZQUIERDA" << std::endl;
}
else if (juga_boundingBox.intersects(object.getGlobalBounds())  && juga.getPosition().y  > object.getPosition().y + object.getSize().y - 7 && juga.getPosition().y < object.getPosition().y + object.getSize().x + 7)
{
    juga.setPosition(juga.getPosition().x, object.getPosition().y + 100);
    velocidad.y = 0;
    std::cout << "ABAJO" << std::endl;
}           
*/