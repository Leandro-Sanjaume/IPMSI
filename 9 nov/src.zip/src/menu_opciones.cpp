
#include <SFML/Graphics.hpp>
#include <vector>
#include <iostream>
#define Max_NUMBER_OF_ITEMS 3

using namespace std;

class Menu_opciones{
	private:
    int selectedItemIndex = 0;
	vector<Menu_opciones> menu_inicial;
    sf:: Font font;
    sf:: Text menu_op[Max_NUMBER_OF_ITEMS]; 
	sf::Texture texture_logo;
	sf::Sprite sprite_ipm;
	sf::Sprite sprite1;
	sf::Texture Background;

 	void move_up(){
            if (selectedItemIndex - 1 >= 0){
                menu_op[selectedItemIndex].setColor(sf::Color::White);
                selectedItemIndex--;
                menu_op[selectedItemIndex].setColor(sf::Color(0,0,255));
            }
        }


        void move_down(){
			if (selectedItemIndex + 1 < Max_NUMBER_OF_ITEMS){
				menu_op[selectedItemIndex].setColor(sf::Color::White);
				selectedItemIndex++;
				menu_op[selectedItemIndex].setColor(sf::Color(0,0,255));
			}
  		}

    public:
        Menu_opciones(float width,float height){

			Background.loadFromFile("assets/sprites/Background.jpg");
			sprite1.setTexture(Background);
			sprite1.setOrigin(menu_op[1].getLocalBounds().width /2, menu_op[1].getLocalBounds().height /2);
			sprite1.setScale(0.8,0.75);

			texture_logo.loadFromFile("assets/sprites/IPM_Dungeon.png");

			sprite_ipm.setTexture(texture_logo);
			sprite_ipm.setOrigin(menu_op[1].getLocalBounds().width /2, menu_op[1].getLocalBounds().height /2);
			sprite_ipm.setPosition((width/2)-250,(height/2)-300);

			font.loadFromFile("assets/fonts/arial.ttf");

            menu_op[0].setFont(font);
            menu_op[0].setColor(sf::Color::Blue);
            menu_op[0].setString("Volumen");
			menu_op[0].setCharacterSize(50);
			menu_op[0].setOrigin(menu_op[0].getLocalBounds().width /2, menu_op[0].getLocalBounds().height /2);
			menu_op[0].setPosition(width/2,(height/2));
		
			

            menu_op[1].setFont(font);
            menu_op[1].setColor(sf::Color::White);
            menu_op[1].setString("Resolucion");
			menu_op[1].setCharacterSize(50);
			menu_op[1].setOrigin(menu_op[1].getLocalBounds().width /2, menu_op[1].getLocalBounds().height /2);
			menu_op[1].setPosition(width/2,(height/2)+65);
	
            
            menu_op[2].setFont(font);
            menu_op[2].setColor(sf::Color::White);
            menu_op[2].setString("Atras");
			menu_op[2].setCharacterSize(50);
			menu_op[2].setOrigin(menu_op[2].getLocalBounds().width /2, menu_op[2].getLocalBounds().height /2);
			menu_op[2].setPosition(width/2,(height/2)+125);
			sf::FloatRect aux2 = menu_op[2].getGlobalBounds();

			//Lionel Andrés Messi Cuccittini was here
	}
		int GetPressedItem() { return selectedItemIndex;}
	


		void draw(sf::RenderWindow &window){
			window.draw(sprite1);
			window.draw(sprite_ipm);
			for (int i = 0; i < Max_NUMBER_OF_ITEMS; i++)
			{ 	
			window.draw(menu_op[i]);
			}
			
		}

        void select_option(int selection, string &window_type, sf::RenderWindow &window){
			if(selection == 0) window_type = "volumen";
			else if(selection == 1) window_type = "Resolucion";
			else if(selection == 2) window_type = "menu";

			cout << window_type << endl;
		}


		int changed(sf::RenderWindow &window, string &window_type, sf::Keyboard::Key key_pressed){
			if(key_pressed == sf::Keyboard::Up) move_up();
			else if(key_pressed == sf::Keyboard::Down) move_down();
			else if(key_pressed == sf::Keyboard::Return) select_option(GetPressedItem(), window_type, window);
			return 3;
		}
};