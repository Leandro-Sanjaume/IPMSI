#pragma once

#include <iostream>
#include <SFML/Graphics.hpp>

class enemy{
    public:

    enemy(){}

    private:
};