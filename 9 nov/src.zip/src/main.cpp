#include <SFML/Graphics.hpp>
#include <iostream>
#include <vector>
#include <cmath>
#include <array>
#include <math.h> 
#include <cfloat>
#include <stack>
#include "player.cpp"
#include "bullet.cpp"
#include "sound.cpp"
#include "menu.cpp"
#include "menu_opciones.cpp"
#include "maps.cpp"
//#include "collitions.cpp"
//#include "func.cpp"

#define X_MAX 1280
#define X_STEP 20
#define Y_MAX 720
#define Y_STEP 20

using namespace std;

void check_colision(sf::RectangleShape& jugador, sf::RectangleShape& object, sf::Vector2f& velocidad)
{
	sf::FloatRect jugador_boundingBox = jugador.getGlobalBounds();


	if (jugador_boundingBox.intersects(object.getGlobalBounds()) && jugador.getPosition().y + jugador.getSize().y < object.getPosition().y + 7 && jugador.getPosition().y + jugador.getSize().y > object.getPosition().y && jugador.getPosition().y < object.getPosition().y)
	{
		jugador.setPosition(jugador.getPosition().x, object.getPosition().y - jugador.getSize().y);

	}
	else if (jugador_boundingBox.intersects(object.getGlobalBounds()) && jugador.getPosition().x > object.getPosition().x + object.getSize().x - 7 && jugador.getPosition().x < object.getPosition().x + object.getSize().x + 7)
	{
		jugador.setPosition(object.getPosition().x + object.getSize().x, jugador.getPosition().y);
		velocidad.x = 0;

	}
	else if (jugador_boundingBox.intersects(object.getGlobalBounds()) && jugador.getPosition().x + jugador.getSize().x < object.getPosition().x + 7 && jugador.getPosition().x + jugador.getSize().x > object.getPosition().x - 7)
	{
		jugador.setPosition(object.getPosition().x - jugador.getSize().x, jugador.getPosition().y);
		velocidad.x = 0;

	}
	else if (jugador_boundingBox.intersects(object.getGlobalBounds()) && jugador.getPosition().y > object.getPosition().y + object.getSize().y - 7 && jugador.getPosition().y < object.getPosition().y + object.getSize().y + 7)
	{
		jugador.setPosition(jugador.getPosition().x, object.getPosition().y + object.getSize().y);
		velocidad.y = 0;

	}
	return;
}


struct Node
{
	int y;
	int x;
	int parentX;
	int parentY;
	float gCost;
	float hCost;
	float fCost;
};

sf::Vector2f normalize(sf::Vector2f source, float speed){
    float length = sqrt(pow(source.x, 2) + pow(source.y, 2));
    if(length != 0) return sf::Vector2f((source.x / length) * speed, (source.y / length) * speed);
    else return source * speed;
}

inline bool operator < (const Node& lhs, const Node& rhs)
{ //We need to overload "<" to put our struct into a set
	return lhs.fCost < rhs.fCost;
}


class Cordinate {
public:


	static bool isValid(int x, int y) { //If our Node is an obstacle it is not valid
		int id = x + y * (X_MAX / X_STEP);
		/// World borders check
		if (1) {
			if (x < 0 || y < 0 || x >= X_MAX || y >= Y_MAX) {
				return false;
			}
			return true;
		}
		return false;
	}

	static bool isDestination(int x, int y, Node dest) {
		if (x == dest.x && y == dest.y) {
			return true;
		}
		return false;
	}

	static double calculateH(int x, int y, Node dest) {
		double H = (sqrt((x - dest.x) * (x - dest.x)
			+ (y - dest.y) * (y - dest.y)));
		return H;
	}

	static std::vector<Node> makePath(std::array<std::array<Node, (Y_MAX / Y_STEP)>, (X_MAX / X_STEP)> map, Node dest) {
		try {
			int x = dest.x;
			int y = dest.y;
			std::stack<Node> path;
			std::vector<Node> usablePath;

			while (!(map[x][y].parentX == x && map[x][y].parentY == y)
				&& map[x][y].x != -1 && map[x][y].y != -1)
			{
				path.push(map[x][y]);
				int tempX = map[x][y].parentX;
				int tempY = map[x][y].parentY;
				x = tempX;
				y = tempY;

			}
			path.push(map[x][y]);

			while (!path.empty()) {
				Node top = path.top();
				path.pop();
				//cout << top.x << " " << top.y << endl;
				usablePath.emplace_back(top);
			}
			return usablePath;
		}
		catch (const std::exception& e) {
			std::cout << e.what() << std::endl;
		}
	}


	static std::vector<Node> aStar(Node player, Node dest) {
		std::vector<Node> empty;
		if (isValid(dest.x, dest.y) == false) {
			std::cout << "Destination is an obstacle" << std::endl;
			return empty;
			//Destination is invalid
		}
		if (isDestination(player.x, player.y, dest)) {
			std::cout << "You are the destination" << std::endl;
			return empty;
			//You clicked on yourself
		}
		bool closedList[(X_MAX / X_STEP)][(Y_MAX / Y_STEP)];

		//Initialize whole map
		//Node allMap[50][25];
		std::array<std::array<Node, (Y_MAX / Y_STEP)>, (X_MAX / X_STEP)> allMap;
		for (int x = 0; x < (X_MAX / X_STEP); x++) {
			for (int y = 0; y < (Y_MAX / Y_STEP); y++) {
				allMap[x][y].fCost = FLT_MAX;
				allMap[x][y].gCost = FLT_MAX;
				allMap[x][y].hCost = FLT_MAX;
				allMap[x][y].parentX = -1;
				allMap[x][y].parentY = -1;
				allMap[x][y].x = x;
				allMap[x][y].y = y;

				closedList[x][y] = false;
			}
		}

		//Initialize our starting list
		int x = player.x;
		int y = player.y;
		allMap[x][y].fCost = 0.0;
		allMap[x][y].gCost = 0.0;
		allMap[x][y].hCost = 0.0;
		allMap[x][y].parentX = x;
		allMap[x][y].parentY = y;

		std::vector<Node> openList;
		openList.emplace_back(allMap[x][y]);
		bool destinationFound = false;

		while (!openList.empty() && openList.size() < (X_MAX / X_STEP) * (Y_MAX / Y_STEP)) {
			Node node;
			do {
				//This do-while loop could be replaced with extracting the first
				//element from a set, but you'd have to make the openList a set.
				//To be completely honest, I don't remember the reason why I do
				//it with a vector, but for now it's still an option, although
				//not as good as a set performance wise.
				float temp = FLT_MAX;
				std::vector<Node>::iterator itNode;
				for (std::vector<Node>::iterator it = openList.begin();
					it != openList.end(); it = next(it)) {
					Node n = *it;
					if (n.fCost < temp) {
						temp = n.fCost;
						itNode = it;
					}
				}
				node = *itNode;
				openList.erase(itNode);
			} while (isValid(node.x, node.y) == false);

			x = node.x;
			y = node.y;
			closedList[x][y] = true;

			//For each neighbour starting from North-West to South-East
			for (int newX = -1; newX <= 1; newX++) {
				for (int newY = -1; newY <= 1; newY++) {
					double gNew, hNew, fNew;
					if (isValid(x + newX, y + newY)) {
						if (isDestination(x + newX, y + newY, dest))
						{
							//Destination found - make path
							allMap[x + newX][y + newY].parentX = x;
							allMap[x + newX][y + newY].parentY = y;
							destinationFound = true;
							return makePath(allMap, dest);
						}
						else if (closedList[x + newX][y + newY] == false)
						{
							gNew = node.gCost + 1.0;
							hNew = calculateH(x + newX, y + newY, dest);
							fNew = gNew + hNew;
							// Check if this path is better than the one already present
							if (allMap[x + newX][y + newY].fCost == FLT_MAX ||
								allMap[x + newX][y + newY].fCost > fNew)
							{
								// Update the details of this neighbour node
								allMap[x + newX][y + newY].fCost = fNew;
								allMap[x + newX][y + newY].gCost = gNew;
								allMap[x + newX][y + newY].hCost = hNew;
								allMap[x + newX][y + newY].parentX = x;
								allMap[x + newX][y + newY].parentY = y;
								openList.emplace_back(allMap[x + newX][y + newY]);
							}
						}
					}
				}
			}
		}
		if (destinationFound == false) {
			std::cout << "Destination not found" << std::endl;
			return empty;
		}
	}
};

void perder_vida(sf::RectangleShape  receiver, int &vida, int damage, sf::CircleShape coli, int vida_atacante, int &ancho, int largo, float aux, sf::RectangleShape& object) {
	if (vida_atacante <= 0) {
		return;
	}

	std::cout<<receiver.getPosition().x << ", " << receiver.getPosition().y;

	sf::FloatRect attacker_boundingBox = coli.getGlobalBounds();
	sf::FloatRect receiver_boundingBox = receiver.getGlobalBounds();

	if (attacker_boundingBox.intersects(receiver_boundingBox)) {
		if (vida <= 0) {
		std::cout << "Moriste" << std::endl;
		}
		else 
		{
			ancho -= aux;
			vida -= damage;
		    object.setSize(sf::Vector2f(ancho, largo));
		}
	}
}
void bullet_collision( std::vector<bullet> &bullets, sf::RectangleShape receiver, bool &bullet_hit){
	 for(int i = 0; i < bullets.size(); i++){
		sf::FloatRect boundingBox_bullets = bullets[i].bsprite.getGlobalBounds();
		sf::FloatRect boundingBox_receiver = receiver.getGlobalBounds();
	
			
            if(boundingBox_bullets.intersects(boundingBox_receiver)){
				bullets.erase(bullets.begin() + i);
				bullet_hit = true;
				//break;
			}
        }
}

		/////// SPRITE ENE
		 void update_sprite(sf::Sprite &enemy, int sprite_originx, int sprite_timer){
            if(sprite_timer > 5){
                sprite_originx += 32;
                sprite_timer = 0;
            }
            else if(sprite_originx == 96) sprite_originx = 0;
            enemy.setTextureRect(sf::IntRect(sprite_originx, 0, 32,36));
        }



int main()
{
    sf::ContextSettings settings;
    settings.antialiasingLevel = 8;
    sf::RenderWindow window(sf::VideoMode(/*sf::VideoMode::getDesktopMode()*/ 1280, 720), "Wachin magico que te caga a tiros", sf::Style::Default, settings);
    sf::Vector2i screencenter(sf::VideoMode::getDesktopMode().width/2 - window.getSize().x/2, sf::VideoMode::getDesktopMode().height/2 - window.getSize().y/2);
    window.setKeyRepeatEnabled(true);
    window.setPosition(screencenter);
    window.setMouseCursorVisible(false);
	window.setFramerateLimit(60);

    sf::Clock reloj;
    sf::Clock ataque_cooldown_enemigo;
	sf::Clock respawn_ene;
	// PAREDES
	sf::RectangleShape pared_aba(sf::Vector2f(1280,25));
	sf::RectangleShape pared_ari(sf::Vector2f(1280,25));
	sf::RectangleShape pared_der(sf::Vector2f(25,720));	
	sf::RectangleShape pared_izq(sf::Vector2f(25,720));	
	pared_aba.setPosition(0,720);
	pared_ari.setPosition(0,0);
	pared_der.setPosition(1280,0);
	pared_izq.setPosition(0,0);
	player p1("assets/sprites/player/player_atlas32x32.png", "assets/sprites/player/player_bullet.png", sf::Vector2f(window.getSize().x/2, window.getSize().y/2));	    
	sf::RectangleShape p1_box(sf::Vector2f(32,36));
    p1_box.setOrigin(p1_box.getSize().x /2, p1_box.getSize().y /2);
    int vida_juga = 100; 
	int ancho_juga = 500;
 	int largo_juga = 20;
 	int largo_en = 10;
 	int ancho_en = 100;
	sf::RectangleShape HUD_vida_jugador(sf::Vector2f(500.0f, 20.f));
 	HUD_vida_jugador.setFillColor(sf::Color::Green);
 	HUD_vida_jugador.setPosition(20, 30);	
    sf::CircleShape circulo_path_jugador(25);
    sf::CircleShape coli_jugador(52);
	coli_jugador.setFillColor(sf::Color::Transparent);
	coli_jugador.setOutlineColor(sf::Color::White);
	coli_jugador.setOutlineThickness(2);
    coli_jugador.setOrigin(coli_jugador.getRadius(), coli_jugador.getRadius());
	coli_jugador.setPosition(p1.get_absolute_position().x, p1.get_absolute_position().y);
	circulo_path_jugador.setFillColor(sf::Color::Transparent);
	circulo_path_jugador.setOutlineColor(sf::Color::Red);
	circulo_path_jugador.setOutlineThickness(4);
    circulo_path_jugador.setOrigin(circulo_path_jugador.getRadius(),circulo_path_jugador.getRadius());

    sound music("assets/sounds/sound1.wav", 100.f);
	
    std::vector<bullet> bullets;
    bool bullet_hit = false;
    // ENEMIGO
	sf::Sprite enemy;
	sf::RectangleShape enemy_box(sf::Vector2f(33,36));
	sf::Texture enemy_text;
	  enemy_box.setOrigin(enemy_box.getSize().x /2, enemy_box.getSize().y /2);
	enemy_text.loadFromFile("assets/sprites/enemy/enemy_atlas36px.png");
	enemy.setTexture(enemy_text);
	enemy.setPosition(window.getSize().x / 2 + 100, window.getSize().y / 2); // 33 x 36

	  	int sprite_originx = 0;
    	int sprite_timer = 0;
    	sf::IntRect current_frame = sf::IntRect(sprite_originx, 0, 33, 36);

    sf::CircleShape coli_enemigo(48);
	coli_enemigo.setFillColor(sf::Color::Transparent);
	coli_enemigo.setOutlineColor(sf::Color::Blue);
	coli_enemigo.setOutlineThickness(2);
	coli_enemigo.setPosition(enemy.getPosition().x, enemy.getPosition().y);
   
    float valor_cooldown_enem = 1;
    int  damage_ene = 20;
    int vida_enemigo = 100;
	float ecuacion_damage_al_juga = ancho_juga / vida_juga * damage_ene;
	float ecuacion_damage_al_ene = ancho_en / vida_enemigo * 5;
	float ecuacion_damage_al_ene_mele = ancho_en / vida_enemigo * 10;
    bool focus = true;
	sf::RectangleShape HUD_vida_enemigo(sf::Vector2f(100.0f, 10.f));
	HUD_vida_enemigo.setFillColor(sf::Color::Red);

	 int basic_clock_ataque_ene = 0;
	 int basic_clock_respawn = 0;
	 int basic_clock_ataque_jug = 0;
	int basic_clock_cambio_armas = 0;
	 int puntos = 0;
	 int contador_armas = 0;
	 sf::Text puntos_str;
	  sf:: Font fuente;
	  sf::Text arma;
	fuente.loadFromFile("assets/fonts/arial.ttf");
	  puntos_str.setFont(fuente);
		arma.setFont(fuente);
		arma.setPosition(750, 30);
			arma.setString("MAGIA");
	//Menu
	Menu menu(window.getSize().x, window.getSize().y);
	Menu_opciones menu_op(window.getSize().x, window.getSize().y);
	std::string window_type = "menu";



   tilemap map("assets/sprites/mapgen/wall_atlas64x64.png" ,sf::Vector2u(64, 64));
    if(!map.load()) return EXIT_FAILURE;

    while(window.isOpen())
    {
        float delta_time = reloj.restart().asSeconds();
        sf::Event event;
      
        while(window.pollEvent(event))
        {
            switch (event.type)
            {
				case sf::Event::KeyReleased:

				if(window_type == "menu") menu.changed(window, window_type, event.key.code);
				else if(window_type == "opciones" || window_type == "resolucion" || window_type == "volumen") menu_op.changed(window, window_type, event.key.code);
					
				break;

            case event.Closed:
                window.close();
                break;

            case sf::Event::LostFocus:
                focus = false;
                break;
                    
            case sf::Event::GainedFocus:  
                focus = true;
                break;
					
            default:
                break;
            }
        }

        // Movement
        sf::Vector2f dir;
        if(focus){
            sf::Vector2f dir = p1.move_player(delta_time, window);
            
        }

		if(sf::Keyboard::isKeyPressed (sf::Keyboard::Q) && basic_clock_cambio_armas >= 20){
				if(contador_armas == 1){
					arma.setString("MAGIA");
					contador_armas = 0;
					basic_clock_cambio_armas = 0;
				}
				else if(contador_armas == 0){
					arma.setString("MELEE");
					contador_armas = 1;
					basic_clock_cambio_armas = 0;
				}
			}
			else{
				basic_clock_cambio_armas ++;
			}
		
		if(contador_armas == 0){
			p1.shoot(bullets);
		}
		  for(int i = 0; i < bullets.size(); i++){
            bullets[i].move_bullet(30, delta_time);
        }
		if(contador_armas == 1){
			if (sf::Mouse::isButtonPressed(sf::Mouse::Left)){
				if (basic_clock_ataque_jug >= 60) {
			perder_vida(enemy_box, vida_enemigo, 10 ,coli_jugador, vida_juga, ancho_en, largo_en, ecuacion_damage_al_ene_mele, HUD_vida_enemigo);
			basic_clock_ataque_ene = 0;
			cout << vida_juga << endl;
		}
		else{
			basic_clock_ataque_jug ++;
		}

			}
		}


		if (vida_enemigo > 0) {
        // PATHFINDING 
		Node enemigo;
		enemigo.x = enemy.getPosition().x / X_STEP;
		enemigo.y = enemy.getPosition().y / Y_STEP;

		Node destination;
		destination.x = p1.get_absolute_position().x / X_STEP;
		destination.y = p1.get_absolute_position().y / Y_STEP;






		for (Node node : Cordinate::aStar(enemigo, destination)) {

			sf::FloatRect jugador_boundingBox = circulo_path_jugador.getGlobalBounds();
			sf::FloatRect enemigo_boundingBox = enemy.getGlobalBounds();
			if (enemigo_boundingBox.intersects(jugador_boundingBox) == false) {
				if (enemy.getPosition().x  - 10 > node.x * 20) {
					enemy.move(-0.3f, 0.f);
					update_sprite(enemy, sprite_originx, sprite_timer);
				}
				else if (enemy.getPosition().x  < node.x * 20) {
					enemy.move(0.3, 0.f);
					update_sprite(enemy, sprite_originx, sprite_timer);
				}

				if (enemy.getPosition().y  > node.y * 20) {
					enemy.move(0.f, -0.3f);
					update_sprite(enemy, sprite_originx, sprite_timer);
				}
				else if (enemy.getPosition().y < node.y * 20) {
					enemy.move(0.f, 0.3f);
					update_sprite(enemy, sprite_originx, sprite_timer);

				}
				coli_enemigo.setPosition(enemy.getPosition().x - enemy_box.getSize().x /  1.05, enemy.getPosition().y - enemy_box.getSize().y / 1.3);
			}
			else {
				enemy.move(0.f, 0.f);
				sprite_originx = 0;
				}
			}
        }
		enemy_box.setPosition(enemy.getPosition().x + 15, enemy.getPosition().y + 23);
		puntos_str.setString("Puntos: " + to_string(puntos));
		HUD_vida_enemigo.setPosition(enemy.getPosition().x - 30, enemy.getPosition().y - 20);
        coli_jugador.setPosition(p1.get_absolute_position().x - p1.get_size().x / 1.9, p1.get_absolute_position().y - p1.get_size().y / 1.9);
		circulo_path_jugador.setPosition(p1.get_absolute_position().x - p1.get_size().x / 2 , p1.get_absolute_position().y - p1.get_size().y / 2 - 2);


		if(bullet_hit == true){
			
			vida_enemigo -=  bullets[0].damage_bullet;
			ancho_en -= ecuacion_damage_al_ene;
		    HUD_vida_enemigo.setSize(sf::Vector2f(ancho_en, largo_en));
			bullet_hit = false;
		}


		

        // Draw
		  // Draw
        window.clear();

		if(window_type == "menu") menu.draw(window);
		else if(window_type == "opciones") menu_op.draw(window);
		else if(window_type == "resolucion") menu_op.draw(window);
		else if(window_type == "volumen") menu_op.draw(window);
		else if(window_type == "juego"){	
        window.draw(map);
		if (vida_enemigo > 0) {
			bullet_collision(bullets, enemy_box, bullet_hit);
			window.draw(enemy);
			window.draw(coli_enemigo);
			window.draw(HUD_vida_enemigo); 
			if (basic_clock_ataque_ene >= 60) {
			perder_vida(p1_box, vida_juga, damage_ene, coli_enemigo, vida_enemigo, ancho_juga, largo_juga, ecuacion_damage_al_juga, HUD_vida_jugador);
			basic_clock_ataque_ene = 0;
			cout << vida_juga << endl;
			
		}
		else{
			basic_clock_ataque_ene ++;
		}
		}
		
			else{
				if (basic_clock_respawn >= 60){
					puntos ++;
					largo_en = 10;
					ancho_en = 100;
					damage_ene = 20;
					vida_enemigo = 100;
					enemy.setPosition(window.getSize().x / 2 + 100, window.getSize().y / 2);
					coli_enemigo.setPosition(enemy.getPosition().x - enemy_box.getSize().x / 1.9, enemy.getPosition().y - enemy_box.getSize().y / 1.9);
					bullet_collision(bullets, enemy_box, bullet_hit);
					window.draw(enemy);
					window.draw(HUD_vida_enemigo); 
					basic_clock_respawn = 0;
				}

				else{
					basic_clock_respawn ++;
				}
			}

			if (vida_juga > 0) {
				window.draw(coli_jugador);
				window.draw(circulo_path_jugador);
				p1_box.setPosition(p1.get_absolute_position());
				window.draw(HUD_vida_jugador);
				p1.draw_player(window);
				window.draw(arma);
			}
		


		
			for(int i = 0; i < bullets.size(); i++){
				bullets[i].draw_bullet(window);
				if(bullets[i].get_absolute_position().y > window.getSize().y ||
				bullets[i].get_absolute_position().y < 0 ||
				bullets[i].get_absolute_position().x > window.getSize().x ||
				bullets[i].get_absolute_position().x < 0) bullets.erase(bullets.begin() + i);
			}
				if(vida_juga <= 0){
				sf::Sprite sprite_die;
				sf::Texture die;
			    die.loadFromFile("assets/sprites/die.jpg");
				sprite_die.setTexture(die);
				sprite_die.setOrigin(0,0);
				sprite_die.setScale(1.1,1);
				window.draw(sprite_die);

			}
		
			music.input();
			
			window.draw(puntos_str);
			

		}
        window.display();

        // Watches
        //printf("Bullets = %lu \n", bullets.size());
        //printf("Delta = %f \n", delta_time);
        //printf("%i\n", vida_juga);
    }
	return 0;
}