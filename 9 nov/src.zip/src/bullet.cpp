#pragma once

#include <iostream>
#include <cmath>
#include <SFML/Graphics.hpp>

//#include "func.cpp"
class bullet{
    public:
        sf::Sprite bsprite;
        float damage_bullet = 5;
        bullet(sf::Texture &texture, sf::Vector2f origin, sf::Vector2f dir, float iniSpeed){
            bsprite = sf::Sprite(texture);
            bsprite.setOrigin(bsprite.getScale().x / 2, bsprite.getScale().y / 2);
            bsprite.setPosition(origin);
            
            direction = dir;
            speed = iniSpeed;
        }

        sf::Vector2f get_absolute_position(){
            return sf::Vector2f(bsprite.getPosition().x - bsprite.getScale().x / 2, bsprite.getPosition().y - bsprite.getScale().y / 2);
        }

        void draw_bullet(sf::RenderWindow &window){
            window.draw(bsprite);
        }

        void move_bullet(float acceleration, float dt){
            bsprite.setPosition(bsprite.getPosition() + normalize(direction) * (acceleration * dt));
        }
    private:
     
        
        sf::Vector2f direction;
        float speed;

        sf::Vector2f normalize(sf::Vector2f source){
            float length = sqrt(pow(source.x, 2) + pow(source.y, 2));
            if(length != 0) return sf::Vector2f((source.x / length) * speed, (source.y / length) * speed);
            else return source * speed;
        }
};